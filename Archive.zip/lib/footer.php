<?php

function getFooter() {
    ?>
    <
    <div id="footer" class="container-fluid text-center">
        <div class="row">
            <div class="col-xs-12 inner">
                <ul class="icons">
                    <li><h5><img src="../../img/navegador.png"><a href="http://www.cobay.edu.mx/" class="icon alt fa-twitter"><span class="label">Pagina Oficial</span></a>
                        <img src="../../img/facebook.png"><a href="https://www.facebook.com/COBAYPlantelProgreso/" class="icon alt fa-twitter"><span class="label">Facebook</span></a>
                        <img src="../../img/arroba.png"><span class="label">Correo: cobay@cobay.edu.mx</span></a>
                        <img src="../../img/whatsapp.png"><span class="label">Telefono: (999) 611.86.90</span></a></h5></li>
            </div>
        </div>
    </div>

    <?php
}
